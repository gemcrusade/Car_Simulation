# Define the directions and corresponding movements
DIRECTIONS = ['N', 'E', 'S', 'W']
MOVEMENTS = {
    'N': (0, 1),  # North: y + 1
    'E': (1, 0),  # East: x + 1
    'S': (0, -1), # South: y - 1
    'W': (-1, 0)  # West: x - 1
}

class Car:
    def __init__(self, name, x, y, direction, commands):
        self.name = name
        self.x = x
        self.y = y
        self.direction = direction
        self.commands = commands
        self.command_index = 0  # To keep track of which command we're at
        self.stopped = False  # To track if the car has collided and stopped

    def move(self):
        if self.stopped:
            return  # Do nothing if the car has already stopped

        if self.command_index < len(self.commands):
            command = self.commands[self.command_index]
            self.command_index += 1

            if command == 'L':  # Turn left
                self.turn_left()
            elif command == 'R':  # Turn right
                self.turn_right()
            elif command == 'F':  # Move forward
                self.move_forward()
            elif command == 'B':  # Move backward
                self.move_backward()

    def turn_left(self):
        self.direction = DIRECTIONS[(DIRECTIONS.index(self.direction) - 1) % 4]

    def turn_right(self):
        self.direction = DIRECTIONS[(DIRECTIONS.index(self.direction) + 1) % 4]

    def move_forward(self):
        dx, dy = MOVEMENTS[self.direction]
        self.x += dx
        self.y += dy

    def move_backward(self):
        dx, dy = MOVEMENTS[DIRECTIONS[(DIRECTIONS.index(self.direction) + 2) % 4]]
        self.x += dx
        self.y += dy

    def __repr__(self):
        return f"{self.name}, ({self.x},{self.y}) {self.direction}, {self.commands}"

def check_collision(cars):
    for i in range(len(cars)):
        for j in range(i + 1, len(cars)):
            if cars[i].x == cars[j].x and cars[i].y == cars[j].y:
                return (cars[i], cars[j])
    return None

def run_simulation(cars):
    steps = 0
    while any(not car.stopped and car.command_index < len(car.commands) for car in cars):
        steps += 1
        for car in cars:
            if not car.stopped:
                car.move()

        # Check for collisions after each move
        collision = check_collision(cars)
        if collision:
            car_a, car_b = collision
            car_a.stopped = True
            car_b.stopped = True
            print(f"Collision detected at step {steps}: {car_a.name} collides with {car_b.name} at ({car_a.x}, {car_a.y})")
            break  # Exit the loop after collision

    return steps, collision

def prompt_for_car(cars):
    name = input("Please enter the name of the car: ")

    # Ensure the name is not already taken
    while any(car.name == name for car in cars):
        print("That name is already taken. Please choose a different name.")
        name = input("Please enter the name of the car: ")

    x, y, direction = input(f"Please enter initial position of car {name} in x y Direction format: ").split()
    x, y = int(x), int(y)

    while direction not in DIRECTIONS:
        print("Invalid direction. Please choose one of N, S, E, W.")
        direction = input(f"Please enter initial position of car {name} in x y Direction format: ").split()[2]

    commands = input(f"Please enter the commands for car {name}: ")

    # Create the car object and add to the cars list
    new_car = Car(name, x, y, direction, commands)
    cars.append(new_car)
    print(f"Your current list of cars are: ")
    for car in cars:
        print(f"- {car}")

def start_simulation():
    # Main driver for starting over or exiting
    cars = []
    while True:
        print("\nPlease choose from the following options:")
        print("[1] Add a car to field")
        print("[2] Run simulation")
        print("[3] Exit")
        choice = input("Enter your choice (1, 2, or 3): ")

        if choice == '1':
            prompt_for_car(cars)

        elif choice == '2':
            print("\nRunning the simulation...\n")
            steps, collision = run_simulation(cars)

            if collision:
                car_a, car_b = collision
                print(f"\nAfter simulation, the result is:")
                print(f"- {car_a.name}, collides with {car_b.name} at ({car_a.x},{car_a.y}) at step {steps}")
                print(f"- {car_b.name}, collides with {car_a.name} at ({car_b.x},{car_b.y}) at step {steps}")
            else:
                print("\nAfter simulation, no collision occurred.")

            # Ask if user wants to start over or exit
            print("\nPlease choose from the following options:")
            print("[1] Start over")
            print("[2] Exit")
            choice = input("Enter your choice (1 or 2): ")

            if choice == '1':
                print("\nWelcome to Auto Driving Car Simulation!\n")
                start_simulation()  # Restart simulation from the beginning
                break
            elif choice == '2':
                print("Thank you for running the simulation. Goodbye!")
                break

        elif choice == '3':  # Exit option here
            print("Thank you for running the simulation. Goodbye!")
            break  # Ensure the loop ends when option 3 is selected


if __name__ == "__main__":
    print("Welcome to Auto Driving Car Simulation!\n")
    start_simulation()
