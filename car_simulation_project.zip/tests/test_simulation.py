import unittest
from io import StringIO
import sys
from car_simulation.car_simulation import Car, check_collision, run_simulation, prompt_for_car

class TestCarSimulation(unittest.TestCase):

    def test_car_initialization(self):
        car = Car("A", 1, 2, "N", "FFRFF")
        self.assertEqual(car.name, "A")
        self.assertEqual(car.x, 1)
        self.assertEqual(car.y, 2)
        self.assertEqual(car.direction, "N")
        self.assertEqual(car.commands, "FFRFF")

    def test_car_move_forward(self):
        car = Car("A", 1, 2, "N", "F")
        car.move()
        self.assertEqual(car.x, 1)
        self.assertEqual(car.y, 3)

    def test_car_turn_left(self):
        car = Car("A", 1, 2, "N", "L")
        car.move()
        self.assertEqual(car.direction, "W")

    def test_car_turn_right(self):
        car = Car("A", 1, 2, "N", "R")
        car.move()
        self.assertEqual(car.direction, "E")

    def test_car_move_backward(self):
        car = Car("A", 1, 2, "N", "B")
        car.move()
        self.assertEqual(car.x, 1)
        self.assertEqual(car.y, 1)

    def test_check_collision_no_collision(self):
        car1 = Car("A", 1, 1, "N", "F")
        car2 = Car("B", 2, 2, "E", "F")
        self.assertIsNone(check_collision([car1, car2]))

    def test_run_simulation_no_collision(self):
        car1 = Car("A", 1, 1, "N", "FF")
        car2 = Car("B", 3, 3, "E", "FF")
        steps, collision = run_simulation([car1, car2])
        self.assertEqual(steps, 2)
        self.assertIsNone(collision)

    def test_run_simulation_with_collision(self):
        # Fix the movement to guarantee collision at step 2
        car1 = Car("A", 1, 1, "N", "FF")  # car1 moves to (1, 3)
        car2 = Car("B", 1, 2, "N", "F")   # car2 moves to (1, 3) -> collision with car1

        steps, collision = run_simulation([car1, car2])
        self.assertEqual(steps, 2)  # The cars should collide in 2 steps
        self.assertIsNotNone(collision)  # A collision should occur
        car_a, car_b = collision
        self.assertEqual(car_a.name, "A")
        self.assertEqual(car_b.name, "B")

    def test_prompt_for_car(self):
        # Simulate user input for adding a car
        user_input = StringIO("A\n1 1 N\nFF\n")
        sys.stdin = user_input

        cars = []
        prompt_for_car(cars)

        # Verify that the car was added to the list
        self.assertEqual(len(cars), 1)
        self.assertEqual(cars[0].name, "A")
        self.assertEqual(cars[0].x, 1)
        self.assertEqual(cars[0].y, 1)
        self.assertEqual(cars[0].direction, "N")
        self.assertEqual(cars[0].commands, "FF")

        # Reset stdin
        sys.stdin = sys.__stdin__

if __name__ == '__main__':
    unittest.main()
