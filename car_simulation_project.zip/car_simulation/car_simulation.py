# car_simulation.py

class Car:
    def __init__(self, name, x, y, direction, commands):
        self.name = name
        self.x = x
        self.y = y
        self.direction = direction
        self.commands = commands
        self.command_index = 0  # Tracks the current position in the command list
        self.stopped = False  # Tracks whether the car is stopped due to a collision

    def __str__(self):
        return f"{self.name}, ({self.x},{self.y}) {self.direction}, {self.commands}"

    def move(self):
        if self.stopped:
            return  # The car is stopped due to a collision
        if self.command_index >= len(self.commands):
            return  # No more commands to execute

        command = self.commands[self.command_index]
        if command == 'F':  # Move Forward
            self.move_forward()
        elif command == 'B':  # Move Backward
            self.move_backward()
        elif command == 'L':  # Turn Left
            self.turn_left()
        elif command == 'R':  # Turn Right
            self.turn_right()

        self.command_index += 1  # Move to the next command

    def move_forward(self):
        if self.direction == 'N':
            self.y += 1
        elif self.direction == 'E':
            self.x += 1
        elif self.direction == 'S':
            self.y -= 1
        elif self.direction == 'W':
            self.x -= 1
        print(f"{self.name} moved forward to ({self.x}, {self.y})")

    def move_backward(self):
        if self.direction == 'N':
            self.y -= 1
        elif self.direction == 'E':
            self.x -= 1
        elif self.direction == 'S':
            self.y += 1
        elif self.direction == 'W':
            self.x += 1
        print(f"{self.name} moved backward to ({self.x}, {self.y})")

    def turn_left(self):
        directions = ['N', 'W', 'S', 'E']  # Clockwise order
        current_index = directions.index(self.direction)
        self.direction = directions[(current_index + 1) % 4]
        print(f"{self.name} turned left, now facing {self.direction}")

    def turn_right(self):
        directions = ['N', 'E', 'S', 'W']  # Clockwise order
        current_index = directions.index(self.direction)
        self.direction = directions[(current_index + 1) % 4]
        print(f"{self.name} turned right, now facing {self.direction}")

# Function to check if two cars have collided
def check_collision(cars):
    # Iterate over each pair of cars to check for a collision
    for i in range(len(cars)):
        for j in range(i + 1, len(cars)):
            # If both cars occupy the same position, it's a collision
            if cars[i].x == cars[j].x and cars[i].y == cars[j].y:
                return (cars[i], cars[j])
    return None

# Function to run the simulation
def run_simulation(cars):
    steps = 0
    collision = None
    while any(not car.stopped and car.command_index < len(car.commands) for car in cars):
        steps += 1
        # Move each car in turn
        for car in cars:
            if not car.stopped:
                car.move()  # Move the car

        # Check for collisions after each move
        collision = check_collision(cars)
        if collision:
            car_a, car_b = collision
            car_a.stopped = True
            car_b.stopped = True
            print(f"Collision detected at step {steps}: {car_a.name} collides with {car_b.name} at ({car_a.x}, {car_a.y})")
            break  # Stop the simulation after the collision

    # Debugging print to show final positions of cars
    print("\nFinal positions of cars after simulation:")
    for car in cars:
        print(f"- {car}")

    return steps, collision

# Function to prompt the user to input details for a new car
def prompt_for_car(cars):
    name = input("Please enter the name of the car: ")
    x, y, direction = input("Please enter initial position of car in x y Direction format: ").split()
    commands = input("Please enter the commands for car: ")

    car = Car(name, int(x), int(y), direction, commands)
    cars.append(car)
    print(f"Your current list of cars are: ")
    for c in cars:
        print(f"- {c}")

# Entry point for running the simulation
if __name__ == '__main__':
    cars = []

    # Add two cars (this can be modified as per your needs)
    prompt_for_car(cars)  # Add the first car
    prompt_for_car(cars)  # Add the second car

    # Run the simulation
    steps, collision = run_simulation(cars)

    # Print the result
    print(f"Simulation completed in {steps} steps.")
    if collision:
        car_a, car_b = collision
        print(f"Collision occurred between {car_a.name} and {car_b.name}.")
    else:
        print("No collision occurred.")
